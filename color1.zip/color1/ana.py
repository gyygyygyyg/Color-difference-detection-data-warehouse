import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import cv2
import os
import torch


def run_same():
	plt.rcParams['font.sans-serif']=['Hiragino Sans GB'] # 修改字体
	plt.rcParams['axes.unicode_minus'] = False # 正常显示负号
	#同组对比
	path_1 = './valid/'
	path_2 = './test/'
	files1 = os.listdir(path_1)
	files1.sort()
	files2 = os.listdir(path_2)
	if '.DS_Store' in files1:
		files1.remove('.DS_Store')
	images_data_list = []
	name_list_index = []
	color_d1 = {'1_1':'矿石银','1_2':'星蕴银','1_3':'玉墨银','1_4':'冰河银','1_5':'流星银','3_1':'极光紫','3_2':'星云紫'}
	color_d2 = {'1':'注塑','2':'abs喷涂','3':'喷涂哑光','4':'玻璃纯色','5':'玻璃拉丝','6':'铝氧化','7':'铝氧化拉丝'}

	for file in files1:
		image = cv2.imread(path_1+file)
		image_RGB = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
		images_data_list.append(image_RGB)
		name_list_index.append(color_d1[(file.split('_')[0]+'_'+file.split('_')[1])]+'_'+color_d2[file.split('_')[2]])
	images_data_list = images_data_list[14:]
	name_list_index = name_list_index[14:]
	print(name_list_index)

	images_data = np.stack(images_data_list,axis=0)
	images_data = images_data.swapaxes(1,3)#.reshape(images_data.shape[0],images_data.shape[1],-1)
	images_data = images_data.reshape(images_data.shape[0],images_data.shape[1],images_data.shape[2]*images_data.shape[3])
	images_data_t = torch.Tensor(images_data)
	images_data,_ = images_data_t.mode(dim=2)

	print(images_data.shape)
	n = images_data.shape[0]


	# 计算每个通道的方差，并存储在数组中
	variances = np.zeros((n, n))  # 20张图片，每张图片3个通道
	for i in range(n):
	    for j in range(n):
	    	tensor1 = images_data[i,:].numpy()
	    	tensor2 = images_data[j,:].numpy()
	    	# print(tensor1,tensor2)
	    	# print((tensor1 - tensor2))
	    	# print((tensor1 - tensor2) ** 2)
	    	variances[i, j] = np.sqrt(np.sum((tensor1 - tensor2) ** 2))
	        # variances[i, j] = np.std(images_data[i, :, :, j])


	# 使用seaborn绘制热力图
	plt.figure(figsize=(8, 6))
	ax = sns.heatmap(variances, annot=True, fmt=".0f", cmap='coolwarm')
	ax.set_xticklabels(name_list_index)
	ax.set_yticklabels(name_list_index)

	# 旋转刻度标签以提高可读性
	plt.xticks(rotation=45)
	plt.yticks(rotation=45)
	plt.title("HSV_欧几里德距离")
	plt.show()

def run_diff():
	plt.rcParams['font.sans-serif']=['Hiragino Sans GB'] # 修改字体
	plt.rcParams['axes.unicode_minus'] = False # 正常显示负号
	path_1 = './valid/'
	path_2 = './test/'
	files1 = os.listdir(path_1)
	files1.sort()
	files2 = os.listdir(path_2)
	if '.DS_Store' in files1:
		files1.remove('.DS_Store')
	images_data_list1 = []
	images_data_list2 = []
	name_list_index = []
	color_d1 = {'1_1':'矿石银','1_2':'星蕴银','1_3':'玉墨银','1_4':'冰河银','1_5':'流星银','3_1':'极光紫','3_2':'星云紫'}
	color_d2 = {'1':'注塑','2':'abs喷涂','3':'喷涂哑光','4':'玻璃纯色','5':'玻璃拉丝','6':'铝氧化','7':'铝氧化拉丝'}

	for file in files1:
		file_ = '_'.join(file.split('_')[:3])+'_1.jpg'
		if file_ in files2:
			image1 = cv2.imread(path_1+file)
			image1_RGB = cv2.cvtColor(image1, cv2.COLOR_BGR2Lab)
			images_data_list1.append(image1_RGB)

			image2 = cv2.imread(path_2+file_)
			image2_RGB = cv2.cvtColor(image2, cv2.COLOR_BGR2Lab)
			images_data_list2.append(image2_RGB)

			name_list_index.append(color_d1[(file.split('_')[0]+'_'+file.split('_')[1])]+'_'+color_d2[file.split('_')[2]])

	images_data_list1 = images_data_list1[11:]
	images_data_list2 = images_data_list2[11:]
	name_list_index = name_list_index[11:]
	print(name_list_index)

	images_data1 = np.stack(images_data_list1,axis=0)
	images_data1 = images_data1.swapaxes(1,3)#.reshape(images_data.shape[0],images_data.shape[1],-1)
	images_data1 = images_data1.reshape(images_data1.shape[0],images_data1.shape[1],images_data1.shape[2]*images_data1.shape[3])
	images_data_t1 = torch.Tensor(images_data1)
	images_data1,_ = images_data_t1.mode(dim=2)

	images_data2 = np.stack(images_data_list2,axis=0)
	images_data2 = images_data2.swapaxes(1,3)#.reshape(images_data.shape[0],images_data.shape[1],-1)
	images_data2 = images_data2.reshape(images_data2.shape[0],images_data2.shape[1],images_data2.shape[2]*images_data2.shape[3])
	images_data_t2 = torch.Tensor(images_data2)
	images_data2,_ = images_data_t2.mode(dim=2)


	print(images_data1.shape,images_data2.shape)
	n = images_data1.shape[0]

	print(n)
	# 计算每个通道的方差，并存储在数组中
	variances = np.zeros((n, n))  # 20张图片，每张图片3个通道
	for i in range(n):
	    for j in range(n):
	    	tensor1 = images_data1[i,:].numpy()
	    	tensor2 = images_data2[j,:].numpy()
	    	# print(tensor1,tensor2)
	    	# print((tensor1 - tensor2))
	    	# print((tensor1 - tensor2) ** 2)
	    	variances[i, j] = np.sqrt(np.sum((tensor1 - tensor2) ** 2))
	        # variances[i, j] = np.std(images_data[i, :, :, j])


	# 使用seaborn绘制热力图
	plt.figure(figsize=(8, 6))
	ax = sns.heatmap(variances, annot=True, fmt=".0f", cmap='coolwarm')
	ax.set_xticklabels(name_list_index)
	ax.set_yticklabels(name_list_index)

	# 旋转刻度标签以提高可读性
	plt.xticks(rotation=45)
	plt.yticks(rotation=45)
	plt.title("Lab_欧几里德距离_1组2组差异")
	plt.show()


def run():
	plt.rcParams['font.sans-serif']=['Hiragino Sans GB'] # 修改字体
	plt.rcParams['axes.unicode_minus'] = False # 正常显示负号
	path_1 = './test_同卡片/'
	path_2 = './test/'
	files1 = os.listdir(path_1)
	files1.sort()
	files2 = os.listdir(path_2)
	if '.DS_Store' in files1:
		files1.remove('.DS_Store')
	images_data_list1 = []
	images_data_list2 = []
	name_list_index = []
	color_d1 = {'1_1':'矿石银','1_2':'星蕴银','1_3':'玉墨银','1_4':'冰河银','1_5':'流星银','3_1':'极光紫','3_2':'星云紫'}
	color_d2 = {'1':'注塑','2':'abs喷涂','3':'喷涂哑光','4':'玻璃纯色','5':'玻璃拉丝','6':'铝氧化','7':'铝氧化拉丝'}

	for file in files1:
		file_ = '_'.join(file.split('_')[:3])+'_1.jpg'
		if file_ in files2:
			image1 = cv2.imread(path_1+file)
			image1_RGB = cv2.cvtColor(image1, cv2.COLOR_BGR2Lab)
			images_data_list1.append(image1_RGB)

			image2 = cv2.imread(path_2+file_)
			image2_RGB = cv2.cvtColor(image2, cv2.COLOR_BGR2Lab)
			images_data_list2.append(image2_RGB)

			name_list_index.append(color_d1[(file.split('_')[0]+'_'+file.split('_')[1])]+'_'+color_d2[file.split('_')[2]])

	images_data_list1 = images_data_list1[11:]
	images_data_list2 = images_data_list2[11:]
	name_list_index = name_list_index[11:]
	print(name_list_index)

	images_data1 = np.stack(images_data_list1,axis=0)
	images_data1 = images_data1.swapaxes(1,3)#.reshape(images_data.shape[0],images_data.shape[1],-1)
	images_data1 = images_data1.reshape(images_data1.shape[0],images_data1.shape[1],images_data1.shape[2]*images_data1.shape[3])
	images_data_t1 = torch.Tensor(images_data1)
	images_data1,_ = images_data_t1.mode(dim=2)

	images_data2 = np.stack(images_data_list2,axis=0)
	images_data2 = images_data2.swapaxes(1,3)#.reshape(images_data.shape[0],images_data.shape[1],-1)
	images_data2 = images_data2.reshape(images_data2.shape[0],images_data2.shape[1],images_data2.shape[2]*images_data2.shape[3])
	images_data_t2 = torch.Tensor(images_data2)
	images_data2,_ = images_data_t2.mode(dim=2)


	print(images_data1.shape,images_data2.shape)
	n = images_data1.shape[0]

	print(n)
	# 计算每个通道的方差，并存储在数组中
	variances = np.zeros((n, n))  # 20张图片，每张图片3个通道
	for i in range(n):
	    for j in range(n):
	    	tensor1 = images_data1[i,:].numpy()
	    	tensor2 = images_data2[j,:].numpy()
	    	# print(tensor1,tensor2)
	    	# print((tensor1 - tensor2))
	    	# print((tensor1 - tensor2) ** 2)
	    	variances[i, j] = np.sqrt(np.sum((tensor1 - tensor2) ** 2))
	        # variances[i, j] = np.std(images_data[i, :, :, j])


	# 使用seaborn绘制热力图
	plt.figure(figsize=(8, 6))
	ax = sns.heatmap(variances, annot=True, fmt=".0f", cmap='coolwarm')
	ax.set_xticklabels(name_list_index)
	ax.set_yticklabels(name_list_index)

	# 旋转刻度标签以提高可读性
	plt.xticks(rotation=45)
	plt.yticks(rotation=45)
	plt.title("Lab_欧几里德距离_1组2组差异")
	plt.show()
if __name__ == '__main__':
	# run_same()
	# run_diff()
	run()
